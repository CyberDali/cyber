const initState={loyers:[],loyer:{}, posts: [], post: {}, isLaoding: true}
const adminReducer=(state= initState,action)=>{
    switch(action.type){
        default: return state
    }
}
export default adminReducer