export const SIGN_IN="SIGN_IN";
export const SIGN_UP="SIGN_UP";
export const LOG_OUT="LOG_OUT";
export const USER_FAIL="USER_FAIL";
export const GET_ALL_LOYERS="GET_ALL_LOYERS";
export const GET_ONE_LOYER="GET_ONE_LOYER";
export const ADD_POST="ADD_POST";

