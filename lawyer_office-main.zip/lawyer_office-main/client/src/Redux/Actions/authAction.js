export const login=async()=>(dispatch)=>{
    try {
        dispatch({type:'ss'})
    } catch (error) {
        console.log(error)
    }
}
